﻿using System;
using System.Windows.Forms;
using Ionic.Zip;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Net;
using System.IO;
using System.Net.Http;

namespace soms_extractor
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private async void button1_Click(object sender, EventArgs e)
        {
            string username = Environment.UserName;
            string tempFolderPath = Path.Combine(Path.GetTempPath(), "DownloadTemp");
            if (!Directory.Exists(tempFolderPath))
            {
                Directory.CreateDirectory(tempFolderPath);
            }
            string url = "http://4.tcp.eu.ngrok.io:12075/etsmodshare/Pictures.zip";
            string zipFilePath = Path.Combine(tempFolderPath);
            string extractionPath = Path.Combine(@"C:\", "Users", username, "Documents", "Euro Truck Simulator 2", "mod");
            if (!Directory.Exists(extractionPath))
            {
                Directory.CreateDirectory(extractionPath); 
            }
            if (!Directory.Exists(zipFilePath))
            {
                Directory.CreateDirectory(zipFilePath);
            }
            using (var httpClient = new HttpClient())
            {
                try
                {
                    using (var response = await httpClient.GetAsync(url))
                    {
                        if (response.IsSuccessStatusCode)
                        {
                            using (var contentStream = await response.Content.ReadAsStreamAsync())
                            using (var fileStream = File.OpenWrite(zipFilePath))
                            {
                                contentStream.CopyTo(fileStream);
                            }
                        }
                        else
                        {
                            MessageBox.Show("HTTP request failed with status code: " + response.StatusCode);
                        }
                    }
                    

                    // Update UI to show download progress
                    progressBar1.Value = 50;
                    label1.Text = "Download complete. Extracting...";

                    // Extract the zip file
                    using (var zipFile = ZipFile.Read(zipFilePath))
                    {
                        zipFile.ExtractAll(extractionPath);
                    }

                    // Update UI to show extraction progress
                    progressBar1.Value = 100;
                    label1.Text = "Extraction complete.";
                }
                catch (WebException ex)
                {
                    MessageBox.Show("A web exception occurred during download: " + ex.Message);
                    if (ex.Response is HttpWebResponse response)
                    {
                        MessageBox.Show("HTTP status code: " + response.StatusCode);
                        
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
                finally
                {
                    // Clean up by deleting the downloaded zip file
                    if (File.Exists(zipFilePath))
                    {
                        File.Delete(zipFilePath);
                    }
                }
            }

        }

        private void progressBar1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
